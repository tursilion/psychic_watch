This is a simple magic trick for the Matsucom OnHandPC. It may or may not work with the Ruputer.

Written by Mike Brent aka Tursi of http://harmlesslion.com
Inspired by a Shockwave app by Andy Naughton.
